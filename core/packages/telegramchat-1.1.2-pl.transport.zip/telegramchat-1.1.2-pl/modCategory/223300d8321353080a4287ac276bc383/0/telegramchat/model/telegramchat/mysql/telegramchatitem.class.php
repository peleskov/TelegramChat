<?php
require_once (dirname(__DIR__) . '/telegramchatitem.class.php');
class TelegramChatItem_mysql extends TelegramChatItem {}