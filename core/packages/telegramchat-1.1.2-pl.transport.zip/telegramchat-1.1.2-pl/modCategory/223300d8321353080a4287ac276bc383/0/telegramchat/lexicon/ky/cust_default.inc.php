<?php
$_lang['tgchat_name_support'] = 'Максим';
$_lang['tgchat_role_support'] = 'Жеке жардамчы';
$_lang['tgchat_intro'] = 'Биздин дүкөнгө кош келиңиз. Бүгүн мен сага кантип жардам бере алам?';
$_lang['tgchat_name_client'] = 'Сиз';
$_lang['tgchat_plh_message'] = 'Кабар';