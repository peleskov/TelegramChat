<?php
class TelegramChats extends xPDOObject {}