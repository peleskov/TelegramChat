<?php

$_lang['area_telegramchat_main'] = 'Основные';

$_lang['setting_telegramchat_some_setting'] = 'Какая-то настройка';
$_lang['setting_telegramchat_some_setting_desc'] = 'Это описание для какой-то настройки';