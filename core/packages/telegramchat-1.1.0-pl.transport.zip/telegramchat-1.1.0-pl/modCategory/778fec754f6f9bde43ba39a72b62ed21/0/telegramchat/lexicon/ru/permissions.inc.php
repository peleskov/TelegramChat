<?php
/**
 * English permissions Lexicon Entries for TelegramChat
 *
 * @package TelegramChat
 * @subpackage lexicon
 */
$_lang['telegramchat_save'] = 'Разрешает создание/изменение данных.';