<?php
require_once (dirname(__DIR__) . '/telegramchats.class.php');
class TelegramChats_mysql extends TelegramChats {}