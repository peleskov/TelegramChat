<?php
class tgChat extends xPDOSimpleObject {}