<?php

/**
 * @package telegramchat
 */
class TelegramChatItem extends xPDOSimpleObject
{
}