<?php
class TelegramChat extends xPDOObject {}