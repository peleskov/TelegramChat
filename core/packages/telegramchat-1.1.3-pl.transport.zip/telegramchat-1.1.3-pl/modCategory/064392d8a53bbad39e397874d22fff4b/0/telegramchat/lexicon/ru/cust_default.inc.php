<?php
$_lang['tgchat_name_support'] = 'Максим';
$_lang['tgchat_role_support'] = 'Персональный помощник';
$_lang['tgchat_intro'] = 'Добро пожаловать в наш магазин. Как я могу Вам сегодня помочь?';
$_lang['tgchat_name_client'] = 'Вы';
$_lang['tgchat_plh_message'] = 'Сообщение';
